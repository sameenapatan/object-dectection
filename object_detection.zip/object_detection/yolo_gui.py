import cv2
import torch
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
from ultralytics import YOLO

# Check if GPU is available
device = "cuda" if torch.cuda.is_available() else "cpu"

# Load YOLOv8 model
model = YOLO("yolov8s.pt").to(device)

# Initialize Tkinter window
root = tk.Tk()
root.title("YOLOv8 Object Detection")
root.geometry("800x600")

# Label to display images or webcam feed
image_label = tk.Label(root)
image_label.pack()

def upload_image():
    """Opens file dialog to select an image and runs YOLOv8 detection."""
    file_path = filedialog.askopenfilename(filetypes=[("Image Files", ".jpg;.jpeg;*.png")])
    if not file_path:
        return

    # Run YOLOv8 detection on the selected image
    results = model(file_path)

    # Load image and draw bounding boxes
    img = cv2.imread(file_path)
    for result in results:
        for box in result.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])  # Bounding box coordinates
            conf = box.conf[0].item()  # Confidence score
            label = result.names[int(box.cls[0].item())]  # Class label

            if conf > 0.5:  # Display only high-confidence detections
                cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(img, f"{label} {conf:.2f}", (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    # Convert OpenCV image to PIL format for Tkinter
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = Image.fromarray(img)
    img.thumbnail((600, 400))  # Resize for display
    img_tk = ImageTk.PhotoImage(img)

    # Display detected image in the GUI
    image_label.config(image=img_tk)
    image_label.image = img_tk

def start_webcam():
    """Opens the webcam and runs YOLOv8 for real-time object detection."""
    cap = cv2.VideoCapture(0)

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # Run YOLOv8 detection on the frame
        results = model(frame)

        # Draw bounding boxes and labels
        for result in results:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])  # Bounding box coordinates
                conf = box.conf[0].item()  # Confidence score
                label = result.names[int(box.cls[0].item())]  # Class label

                if conf > 0.5:  # Display only high-confidence detections
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(frame, f"{label} {conf:.2f}", (x1, y1 - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # Display frame
        cv2.imshow("YOLOv8 Webcam Detection", frame)

        # Exit on 'q' key press
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

# Upload button
upload_btn = tk.Button(root, text="Upload Image", command=upload_image, font=("Arial", 14), bg="blue", fg="white")
upload_btn.pack(pady=10)

# Webcam button
webcam_btn = tk.Button(root, text="Start Webcam", command=start_webcam, font=("Arial", 14), bg="green", fg="white")
webcam_btn.pack(pady=10)

# Run the Tkinter event loop
root.mainloop()